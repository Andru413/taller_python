import mysql.connector
from mysql.connector import Error

def conexion():
    try:
        # Conectar a la base de datos
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  
            database="TIENDA"
        )

        # Verificar conexiOn
        if conn.is_connected():
            print("✅ Conexión exitosa a la base de datos.")
            return conn
        else:
            print("Error: No se pudo establecer la conexión.")
            return None

    except Error as e:
        print(f"Error al conectar con la base de datos: {e}")
        return None
