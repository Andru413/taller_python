import time

class SistemaEjercicios:
    def __init__(self):
        self.capacidad_sala = 10  # Para el sistema de reservas

    # ================== EJERCICIO 1: Sistema de Reservas ==================
    def sistema_reservas(self):
        asientos_disponibles = self.capacidad_sala
        print("\n🎬 Bienvenido al Sistema de Reservas de Cine 🎬")
        while asientos_disponibles > 0:
            print(f"Asientos disponibles: {asientos_disponibles}")
            try:
                cantidad = int(input("¿Cuántos asientos desea reservar? "))
                if cantidad <= 0:
                    print("⚠️ Ingrese un número válido mayor a 0.")
                elif cantidad > asientos_disponibles:
                    print("❌ No hay suficientes asientos disponibles.")
                else:
                    asientos_disponibles -= cantidad
                    print(f"✅ Se han reservado {cantidad} asientos.")
            except ValueError:
                print("⚠️ Debe ingresar un número.")
        print("🎉 ¡Todos los asientos han sido reservados!\n")

    # ================== EJERCICIO 2: FizzBuzz ==================
    def fizzbuzz(self):
        print("\n🔥 Juego FizzBuzz del 1 al 100 🔥")
        for i in range(1, 101):
            if i % 3 == 0 and i % 5 == 0:
                print("FizzBuzz")
            elif i % 3 == 0:
                print("Fizz")
            elif i % 5 == 0:
                print("Buzz")
            else:
                print(i)
        print("✅ Fin de FizzBuzz\n")

    # ================== EJERCICIO 3: Calculadora ==================
    def calculadora(self):
        print("\n🧮 Calculadora Simple 🧮")
        while True:
            try:
                num1 = float(input("Ingrese el primer número: "))
                num2 = float(input("Ingrese el segundo número: "))
                operacion = input("Elija operación (+, -, *, /): ")

                if operacion == "+":
                    print(f"Resultado: {num1 + num2}")
                elif operacion == "-":
                    print(f"Resultado: {num1 - num2}")
                elif operacion == "*":
                    print(f"Resultado: {num1 * num2}")
                elif operacion == "/":
                    if num2 == 0:
                        print("❌ No se puede dividir entre 0.")
                    else:
                        print(f"Resultado: {num1 / num2}")
                else:
                    print("⚠️ Operación inválida.")
            except ValueError:
                print("⚠️ Debe ingresar números válidos.")

            otra = input("¿Desea realizar otro cálculo? (s/n): ")
            if otra.lower() != "s":
                break
        print("✅ Fin de la calculadora\n")

    # ================== EJERCICIO 4: Control de Temperatura ==================
    def control_temperatura(self):
        print("\n🌡️ Control de Temperatura en Invernadero 🌡️")
        for _ in range(5):
            temp = float(input("Ingrese temperatura actual (°C): "))
            if temp < 10:
                print("🔥 Activando calefactor...")
            elif 10 <= temp <= 25:
                print("✅ Temperatura adecuada, sistema inactivo.")
            else:
                print("💨 Activando ventilador...")
            time.sleep(2)
        print("✅ Fin de control de temperatura\n")

    # ================== EJERCICIO 5: Detección de Intrusos ==================
    def deteccion_intrusos(self):
        print("\n🚨 Sistema de Detección de Intrusos 🚨")
        alarma_activa = True
        while alarma_activa:
            noche = input("¿Es de noche? (s/n): ").lower() == "s"
            sensores = []
            for i in range(1, 4):
                movimiento = input(f"¿Sensor {i} detecta movimiento? (s/n): ").lower() == "s"
                sensores.append(movimiento)
            if noche and sum(sensores) >= 2:
                print("🚨 ¡ALARMA ACTIVADA! 🚨")
            else:
                print("✅ Sistema en reposo.")
            otra = input("¿Desea continuar? (s/n): ")
            if otra.lower() != "s":
                alarma_activa = False
        print("✅ Fin del sistema de intrusos\n")

    # ================== EJERCICIO 6: Control de Luces ==================
    def control_luces(self):
        print("\n💡 Sistema Automático de Luces 💡")
        for _ in range(5):
            noche = input("¿Es de noche? (s/n): ").lower() == "s"
            movimiento = input("¿Hay movimiento? (s/n): ").lower() == "s"
            if noche and movimiento:
                print("💡 Luces encendidas.")
            else:
                print("💡 Luces apagadas.")
            time.sleep(2)
        print("✅ Fin del control de luces\n")

    # ================== EJERCICIO 7: Aire Acondicionado ==================
    def control_aire(self):
        print("\n❄️ Control de Aire Acondicionado ❄️")
        for _ in range(5):
            temp = float(input("Ingrese temperatura (°C): "))
            humedad = float(input("Ingrese humedad (%): "))
            if (temp > 28 and humedad > 60) or temp > 30:
                print("❄️ Aire acondicionado encendido.")
            else:
                print("✅ Aire acondicionado apagado.")
            time.sleep(2)
        print("✅ Fin del control de aire\n")

    # ================== EJERCICIO 8: Control de Acceso ==================
    def control_acceso(self):
        print("\n🚪 Control de Acceso a la Tienda 🚪")
        for _ in range(5):
            tiene_membresia = input("¿Tiene membresía? (s/n): ").lower() == "s"
            horario = input("¿Está en horario de atención? (s/n): ").lower() == "s"
            es_empleado = input("¿Es empleado? (s/n): ").lower() == "s"

            if (tiene_membresia and horario) or es_empleado:
                print("✅ Acceso permitido.")
            else:
                print("❌ Acceso denegado.")
            time.sleep(1)
        print("✅ Fin del control de acceso\n")


# ================== MENÚ PRINCIPAL ==================
def menu():
    sistema = SistemaEjercicios()

    while True:
        print("\n✨ Bienvenido al sistema de ejercicios en Python ✨")
        print("Seleccione una opción:")
        print("1. Sistema de reservas (Cine)")
        print("2. Juego FizzBuzz")
        print("3. Calculadora simple")
        print("4. Control de temperatura en invernadero")
        print("5. Detección de intrusos")
        print("6. Control de luces automático")
        print("7. Control de aire acondicionado")
        print("8. Control de acceso a una tienda")
        print("9. Salir")

        opcion = input("👉 Ingrese su opción: ")

        if opcion == "1":
            sistema.sistema_reservas()
        elif opcion == "2":
            sistema.fizzbuzz()
        elif opcion == "3":
            sistema.calculadora()
        elif opcion == "4":
            sistema.control_temperatura()
        elif opcion == "5":
            sistema.deteccion_intrusos()
        elif opcion == "6":
            sistema.control_luces()
        elif opcion == "7":
            sistema.control_aire()
        elif opcion == "8":
            sistema.control_acceso()
        elif opcion == "9":
            print("👋 Gracias por usar el sistema. ¡Hasta pronto!")
            break
        else:
            print("⚠️ Opción inválida, intente de nuevo.")


# ================== EJECUTAR ==================
if __name__ == "__main__":
    menu()
